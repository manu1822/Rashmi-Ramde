from django.urls import path
from.import views
urlpatterns = [
   path('',views.raiserequest,name="raiserequest"),
   path('dashboard/<int:objid>/',views.raiserequest1,name="raiserequest1"),
   path('dashboard/<int:objid>/add_opening/',views.addopening_view,name="addopening_view"),
   path('dashboard/<int:objid>/view_opening/',views.viewopening_view,name="viewopening_view"),
   path('dashboard/<int:objid>/<str:rid>/DetailView/',views.detail_opening_view,name="detail_opening_view"),
   path('dashboard/<int:objid>/<str:posid>/AddCand/',views.addcandidate_view,name="addcandidate_view"),
   path('dashboard/<int:objid>/<str:rid>/ViewCand/',views.view_candidate,name="view_candidate"),
   path('dashboard/<int:objid>/<str:emailid>/DetailCandidate/',views.candidate_details_pm_view,name="candidate_details_pm_view"),
   path('dashboard/<int:objid>/<slug:slugid>/AssignView/',views.assignpage_view,name="assignpage_view"),
   path('dashboard/<int:objid>/<str:emailid>/SelectCandidate/',views.selected_candidate_views,name="selected_candidate_views"),
   path('dashboard/<int:objid>/<str:posid>/<str:canddetails>/SendCand/',views.send_candidate_view,name="send_candidate_view"),
   path('dashboard/<int:objid>/<str:rid>/<str:emailid>/delete/',views.deletecandidate,name="deletecandidate"),
   path('dashboard/<int:objid>/<str:emailid>/download_pdf/',views.download_pdf,name="download_pdf"),
   path('dashboard/<int:objid>/viewcandpm/',views.view_candidate_pm,name="view_candidate_pm"),
   path('dashboard/<int:objid>/viewcandrtl/',views.view_candidate_rtl,name="view_candidate_rtl"),
   
   path('signout/',views.signout,name="signout")
]
