from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.models import auth
from django.contrib import messages
from .models import user_profile,addopenings_model,posid_assign_models,comment_model,addcandidate_model
from django.urls import reverse
from django.contrib.auth.models import User
from datetime import datetime
from django.core.mail import EmailMessage
from django.conf import settings
def raiserequest(request):
    if request.method=="POST":
        username=request.POST["username"]
        password=request.POST["password"]
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            obj=user_profile.objects.get(user=user)
            print(obj.user.id)
            return HttpResponseRedirect(reverse("raiserequest1",args=(obj.user.id,)))
        else:
            messages.info(request,"Invalid Credentials")
            return redirect("raiserequest") 
    else:
        return render(request,"index.html")
def raiserequest1(request,objid):
    user=get_object_or_404(User,id=objid)
    print(user.username)
    obj=user_profile.objects.get(user=user)    
    return render(request,"dashboard.html",{"obj":obj})
def addopening_view(request,objid):
    if request.method=="POST":
        rid=request.POST["rid"]
        resby=request.POST["resby"]
        posname=request.POST["posname"]
        client=request.POST["client"]
        project=request.POST["project"]
        reqtype=request.POST["reqtype"]
        restype=request.POST["restype"]
        nop=request.POST["nop"]
        apvdbud=request.POST["apvdbud"]
        mhsc=request.POST["mhsc"]
        gthsc=request.POST["gthsc"]
        totexpy=request.POST["totexpy"]
        totexpm=request.POST["totexpm"]
        rey=request.POST["rey"]
        rem=request.POST["rem"]
        hiqua=request.POST["hiqua"]
        certftn=request.POST["certftn"]
        certdet=request.POST["certdet"]
        cabfacility=request.POST["cabfacility"]
        shiftjob=request.POST["shiftjob"]
        jloc=request.POST["jloc"]
        interloc=request.POST["interloc"]
        rtype=request.POST["rtype"]
        bond_c=request.POST["bond_c"]
        bond=request.POST["bond"]
        deslevl=request.POST["deslevl"]
        reqexp=request.POST["reqexp"]
        poslevl=request.POST["poslevl"]
        minctc=request.POST["minctc"]
        maxctc=request.POST["maxctc"]
        hbyd=request.POST["hbyd"]
        spcond=request.POST["spcond"]
        jobdescrip=request.POST["jobdescrip"]
        img = request.POST["photo"]
        status=addopenings_model.status_ch[-1][0]
        technology=request.POST["technology"]
        user=get_object_or_404(User,id=objid)
        pmname=user.username        
        obj=addopenings_model.objects.create(rid=rid,slug=rid,resby=resby,posname=posname,client=client,proj=project,reqtype=reqtype,restype=restype,nop=nop,appvbud=apvdbud,mhscod=mhsc,gthsc=gthsc,totexpm_m=totexpm,totexpy_m=totexpy,rey_m=rey,rem_m=rem,highqua=hiqua,certftn=certftn,cerdet=certdet,cabfacility=cabfacility,shiftjob=shiftjob,jloc=jloc,interloc=interloc,rtype=rtype,bond_c=bond_c,bond=bond,deslevl=deslevl,reqexp=reqexp,poslevel=poslevl,maxctc=maxctc,minctc=minctc,hbydate=hbyd,splcond=spcond,jobdescrip=jobdescrip,resume=img,status=status,RECEIVED_DATE=datetime.now(),technology=technology,pmname=pmname)
        obj.save()
        pos_id_ch=[rid+"_posid"+str(i+1) for i in range(int(nop))]
        for i in pos_id_ch:
            obj1=posid_assign_models.objects.create(addops=obj,posid=i)
            obj1.save()
    user=get_object_or_404(User,id=objid)
    print(user.username)
    obj=user_profile.objects.get(user=user)
    proj_ch=addopenings_model.proj_ch
    jloc_ch=addopenings_model.jloc_ch
    rey=addopenings_model.rey
    rem=addopenings_model.rem
    totexpy=addopenings_model.totexpy
    totexpm=addopenings_model.totexpm
    restype_ch=addopenings_model.restype_ch
    resby_ch=addopenings_model.resby_ch
    client_ch=addopenings_model.client_ch
    bond_ch=addopenings_model.bond_ch
    deslevl_ch=addopenings_model.deslevl_ch
    reqtype_ch=addopenings_model.reqtype_ch
    cabfacility_ch=addopenings_model.cabfacility_ch
    certftn_ch=addopenings_model.certftn_ch
    return render(request,"add_openingpm.html",{"obj":obj,"bond_ch":bond_ch,"jloc_ch":jloc_ch,"certftn_ch":certftn_ch,"cabfacility_ch":cabfacility_ch,"rey":rey,"rem":rem,"proj_ch":proj_ch,"totexpy":totexpy,"totexpm":totexpm,"restype_ch":restype_ch,"resby_ch":resby_ch,"client_ch":client_ch,"deslevl_ch":deslevl_ch,"reqtype_ch":reqtype_ch})
def view_candidate(request,objid,rid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    if obj.dsg=="pm":
        pass
    else:
        posid_cond=posid_assign_models.objects.get(posid=rid)
        cand_details=addcandidate_model.objects.filter(assignedposid=posid_cond)
        if request.method=="POST":
            res=request.POST.getlist("checks[]")
            print(res)
            canddetails=",".join(res)
            return redirect("send_candidate_view",objid=objid,posid=rid,canddetails=canddetails)
    return render(request,"view_candidate.html",{"obj":obj,"posid_cond":posid_cond,"cand_details":cand_details})
def deletecandidate(request,objid,rid,emailid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    posid_cond=posid_assign_models.objects.get(posid=rid)
    cand_details=addcandidate_model.objects.filter(assignedposid=posid_cond,emailid=emailid).delete()
    return redirect("view_candidate",objid=objid,rid=rid)
def view_candidate_pm(request,objid):
    details={}
    opening=addopenings_model.objects.filter(status="Accepted")
    for i in opening:
        posid_vari=posid_assign_models.objects.filter(addops=i)
        for j in posid_vari:
            cand=addcandidate_model.objects.filter(status__in=["OnHold","Interview_Schedule"],assignedposid=j)
            details[j]=cand
    print(details)
    return render(request,"view_candidatepm.html",{"details":zip(details.keys(),details.values())})
def view_candidate_rtl(request,objid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    details={}
    qual=[""]
    tchnolgy=[""]
    opening=addopenings_model.objects.filter(status="Accepted")
    for i in opening:
        posid_vari=posid_assign_models.objects.filter(addops=i)
        for j in posid_vari:
            cand=addcandidate_model.objects.filter(status__in=["OnHold","Interview_Schedule"],assignedposid=j)
            for k in cand:
                qual.append(k.highedu)
                tchnolgy.append(k.tchnolgy)
            if request.method == "POST":
                new=addcandidate_model.objects.filter(status="OnHold",assignedposid=j)
                qual_v=request.POST.get("for_qua")
                if len(qual_v) ==0:
                    qual_v=[]
                    for i in new:
                        qual_v.append(i.highedu)
                else:
                    qual_v=[qual_v]
                tchnolgy_v=request.POST.get("for_industry")
                if len(tchnolgy_v)==0:
                    tchnolgy_v=[i.tchnolgy for i in new]
                else:
                    tchnolgy_v=[tchnolgy_v]
                name_v=request.POST.get("s_name")
                if len(name_v) ==0:
                    name_v=[i.fname for i in new]
                else:
                    name_v=[name_v]
                from_v=request.POST.get("keyword1")
                to_v=request.POST.get("keyword2")
                if len(to_v) ==0:
                    expt_v=[i.totexpy_m for i in new]
                else:
                    expt_v=[ i for i in range(int(from_v),int(to_v)+1)]
                cand=addcandidate_model.objects.filter(status__in=["OnHold","Interview_Schedule"],assignedposid=j,highedu__in=qual_v,tchnolgy__in=tchnolgy_v,fname__in=name_v,totexpy_m__in=expt_v)
                print(cand)
            details[j]=cand
            
    
    return render(request,"view_candidatertl.html",{"obj":obj,"details":zip(details.keys(),details.values()),"count":1,"qual":qual,"tchnolgy":tchnolgy})
def viewopening_view(request,objid):
    user=get_object_or_404(User,id=objid)
    print(user.username)
    obj=user_profile.objects.get(user=user)
    #obj=request.session['obj']
    addopendata=addopenings_model.objects.all()
    if obj.dsg == "Recuiter":
        posid_cond=posid_assign_models.objects.filter(assign_to=user.username)
        return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata,"posid_cond":posid_cond})        
    return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata})

def detail_opening_view(request,objid,rid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    if obj.dsg == "Recuiter":
        posid_obj=posid_assign_models.objects.get(posid=rid)
        addopendata=posid_obj.addops
    else:
        addopendata=addopenings_model.objects.get(rid=rid)
    if request.method == "POST":
        if obj.dsg=="pm":
            comment=request.POST["comment"]
            newcmd=comment_model.objects.create(pmname=user.username,dsg=obj.dsg,cmddate=datetime.now(),comment=comment)
            newcmd.save()
        elif obj.dsg =="RTL":
            comment=request.POST["comment"]
            status=request.POST["status"]
            newcmd=comment_model.objects.create(pmname=user.username,dsg=obj.dsg,cmddate=datetime.now(),comment=comment)
            newcmd.save()
            addopendata.status=status
            addopendata.save()
        else:
            reqstatus=request.POST["status"]
            posid_obj.reqstatus=reqstatus
            posid_obj.save()
    cmddetails=comment_model.objects.all()
    if obj.dsg == "Recuiter":
        return render(request,"detail_openingpm.html",{"obj":obj,"posid_obj":posid_obj,"addopendata":addopendata,"cmddetails":cmddetails})
    else:
        return render(request,"detail_openingpm.html",{"obj":obj,"addopendata":addopendata,"cmddetails":cmddetails})

def addcandidate_view(request,objid,posid):
    if request.method=="POST":
        fname=request.POST["fname"]
        mname=request.POST["mname"]
        lname=request.POST["lname"]
        contactno=request.POST["contactno"]
        emailid=request.POST["emailid"]
        dob=request.POST["dob"]
        tchnolgy=request.POST["tchnolgy"]
        ssiany=request.POST["ssiany"]
        certiany=request.POST["certiany"]
        highedu=request.POST["highedu"]
        totexpy_m=request.POST["totexpy_m"]
        totexpm_m=request.POST["totexpm_m"]
        relevty_m=request.POST["relevty"]
        relevtm_m=request.POST["relevtm"]
        currctct_T=request.POST["currctct_T"]
        currctcl_L=request.POST["currctct_L"]
        expectct_T=request.POST["expectct_T"]
        expctcl_L=request.POST["expectct_L"]
        currorganztn=request.POST["currorganztn"]
        notcperd=request.POST["notcperd"]
        gender=request.POST["gender"]
        srce=request.POST["srce"]
        prfdloc=request.POST["prfdloc"]
        currloc=request.POST["currloc"]
        pancrd=request.POST["pancrd"]
        passport=request.POST["passport"]
        reaorchange=request.POST["reaorchange"]
        status=addcandidate_model.status_ch[2][0]
        from django.core.files.storage import FileSystemStorage
        uploadresumecan=request.FILES["uploadresumcan"]
        fs=FileSystemStorage()
        uploadresumecan=fs.save(uploadresumecan.name,uploadresumecan)
        
        
        print(uploadresumecan)
        assignedposid=posid_assign_models.objects.get(posid=posid)
        obj=addcandidate_model.objects.create(received_date=datetime.now(),status=status,fname=fname,mname=mname,lname=lname,contactno=contactno,emailid=emailid,dob=dob,
                                              tchnolgy=tchnolgy,ssiany=ssiany,certiany=certiany,highedu=highedu,totexpm_m=totexpm_m,totexpy_m=totexpy_m,
                                              relevty_m=relevty_m,relevtm_m=relevtm_m,currctct_T=currctct_T,currctcl_L=currctcl_L,expectct_T=expectct_T,expctcl_L=expctcl_L,currorganztn=currorganztn,
                                              notcperd=notcperd,gender=gender,srce=srce,prfdloc=prfdloc,currloc=currloc,pancrd=pancrd,passport=passport,
                                              reaorchange=reaorchange,uploadresumecan=uploadresumecan,assignedposid=assignedposid)
        obj.save()
        return render(request,"candidate_details.html",{"obj":obj,"candidatedetail":obj})
        
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    totexpm=addcandidate_model.totexpm
    totexpy=addcandidate_model.totexpy
    relevtm=addcandidate_model.relevtm
    relevty=addcandidate_model.relevty
    currctct=addcandidate_model.currctct
    currctcl=addcandidate_model.currctcl
    expectct=addcandidate_model.expectct
    expctcl=addcandidate_model.expctcl
    gender_ch=addcandidate_model.gender_ch
    assignedposid=posid_assign_models.objects.get(posid=posid)
    addcandidate=addopenings_model.objects.get(rid=assignedposid.addops.rid)
     
    return render(request,"add_candidate.html",{"obj":obj,"assignedposid":assignedposid,"addcandidate":addcandidate,"totexpm":totexpm,"totexpy":totexpy,"relevtm":relevtm,"relevty":relevty,"currctct":currctct,
                                                "currctcl":currctcl,"expectct":expectct,"expctcl":expctcl,"gender_ch":gender_ch})
    
    
    
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    addcand=addopenings_model.objects.get(rid=posid)
    return render(request,"add_candidate.html",{"obj":obj,"addcand":addcand})
def assignpage_view(request,objid,slugid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    addopendata=addopenings_model.objects.get(slug=slugid)
    posid_fields=posid_assign_models.objects.filter(addops=addopendata)#[posid,posid2]
    rtlist=user_profile.objects.filter(dsg="Recuiter")
    if request.method=="POST":
        #comment=request.POST["comment"]
        #assign_f=[]
        comment_h=[]
        for i in posid_fields:
            #assign_f.append(request.POST["assign_"+i.posid])
            i.assign_to=request.POST["assign_"+i.posid]
            i.save()
            newcmd=comment_model.objects.create(pmname=user.username,dsg=obj.dsg,cmddate=datetime.now(),comment=i.posid+request.POST["comment_"+i.posid])
            newcmd.save()
        addopendata=addopenings_model.objects.all()
        return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata})
    if posid_fields[0].assign_to=="":
        return render(request,"assign-recruiter.html",{"obj":obj,"rtlist":rtlist,"addopendata":addopendata,"posid_fields":posid_fields})
    else:
        addopendata=addopenings_model.objects.all()
        return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata})
    
def candidate_details_pm_view(request,objid,emailid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    candidate=addcandidate_model.objects.get(emailid=emailid)
    if request.method == "POST":
        status=request.POST["opening_industry"]
        candidate.status=status
        candidate.save()
        comment=request.POST["comment"]
        newcmd=comment_model.objects.create(pmname=user.username,dsg=obj.dsg,cmddate=datetime.now(),comment=comment)
        newcmd.save()
        return redirect("view_candidate_pm",objid=objid)
    return render(request,'candidate_details_pm.html',{"obj":obj,"candidate":candidate})
from wsgiref.util import FileWrapper
def selected_candidate_views(request,objid,emailid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    candidate=addcandidate_model.objects.get(emailid=emailid)
    return render(request,"selected_candidate.html",{"obj":obj,"candidate":candidate})
def download_pdf(request,objid,emailid):
    print("selcted")
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    candidate=addcandidate_model.objects.get(emailid=emailid)
    print()
    f=open(str(settings.BASE_DIR)+"\\media\\newfile\\"+str(candidate.uploadresumecan),"r")
    responce=HttpResponse(FileWrapper(f), content_type="application/pdf")
    responce["Content-Disposition"]='attachement;filename=resume.pdf'
    f.close()
    return responce
def send_candidate_view(request,objid,posid,canddetails):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    assignedposid=posid_assign_models.objects.get(posid=posid)
    addcandidate=addopenings_model.objects.get(rid=assignedposid.addops.rid)
    canddetails=canddetails.split(",")
    cand_list=[]
    f_l,f=[],[]
    body="Dear Sir, \n Candidate list for {} under {}".format(assignedposid.addops.rid,assignedposid.posid)
    title="Candidate list for {} under {}".format(assignedposid.addops.rid,assignedposid.posid)
    for i in canddetails:
       l=addcandidate_model.objects.get(emailid=i)
       cand_list.append(l)
       body+="{} : {} \n".format(l.fname,l.emailid)
       f.append(str(l.uploadresumecan))
       f_l.append(str(settings.BASE_DIR)+"\\media\\"+str(l.uploadresumecan))
    to="pratheebakgisl@gmail.com, pratheeba.sivaraj@kggroup.com"
    cc="pratheeba24s@gmail.com"
    if request.method == "POST":
        print("done")
        #f="F:\download\FirstKey.pem"
        to=to.split(",")
        cc=cc.split(",")
        email = EmailMessage(
            title,
           body,
            settings.EMAIL_HOST_USER,
            to,
            cc,
            headers={'Message-ID': 'foo'})
        for i in f_l:
            email.attach_file(i)
        email.send(fail_silently=False)
        for i in canddetails:
            l=addcandidate_model.objects.get(emailid=i)
            l.status=l.status_ch[0][0]
            l.save()
        return redirect("view_candidate",objid=objid,rid=posid)
    return render(request,"send_candidate.html",{"obj":obj,"to":to,"cc":cc,"body":body,"title":title,"f":str(f)})
def candidate_details_view(request,objid,emailid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    candidate=addcandidate_model.objects.get(emailid=emailid)
    return render(request,'candidate_details.html',{"obj":obj,"candidate":candidate})

def signout(request):
    auth.logout(request)
    return redirect("raiserequest")