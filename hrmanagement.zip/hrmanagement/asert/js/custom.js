jQuery(document).ready(function(){
jQuery('.leftmenu .dropdown> a').click(function(){
if(!jQuery(this).next().is(':visible'))jQuery(this).next().slideDown('fast');
else jQuery(this).next().slideUp('fast');return false;});
if(jQuery.uniform)jQuery('input:checkbox, input:radio, .uniform-file').uniform();
if(jQuery('.widgettitle .close').length> 0){jQuery('.widgettitle .close').click(function(){jQuery(this).parents('.widgetbox').fadeOut(function(){jQuery(this).remove();});});}/* add menu bar for phones and tablet */jQuery('<div class="topbar"><a class="barmenu">'+'</a></div>').insertBefore('.mainwrapper');jQuery('.topbar .barmenu').click(function(){var lwidth = '260px';
if(jQuery(window).width()< 340){lwidth = '240px';}
if(!jQuery(this).hasClass('open')){jQuery('.rightpanel, .headerinner, .topbar').css({marginLeft: lwidth},'fast');jQuery('.logo, .leftpanel').css({marginLeft: 0},'fast');jQuery(this).addClass('open');}
else{jQuery('.rightpanel, .headerinner, .topbar').css({marginLeft: 0},'fast');jQuery('.logo, .leftpanel').css({marginLeft: '-'+lwidth},'fast');jQuery(this).removeClass('open');}});/*show/hide left menu*/jQuery(window).resize(function(){if(!jQuery('.topbar').is(':visible')){jQuery('.rightpanel, .headerinner').css({marginLeft: '260px'});jQuery('.logo, .leftpanel').css({marginLeft: 0});} 
else{jQuery('.rightpanel, .headerinner').css({marginLeft: 0});jQuery('.logo, .leftpanel').css({marginLeft: '-260px'});}});/* load selected skin color from cookie */});