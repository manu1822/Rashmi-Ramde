from django.shortcuts import render
from django.http import HttpResponse
def homepage(request):
    return HttpResponse("Hello")
def contact(request):
    return HttpResponse("<h1>I Am Here</h1>")
    
    
    
    
