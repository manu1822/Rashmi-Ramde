from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.models import auth
from django.contrib import messages
from .models import user_profile,addopening_model,POID_assign_model,commentlist_model,addcandidate_model,history_model
from django.urls import reverse
from django.contrib.auth.models import User
from datetime import datetime
from django.core.files.storage import FileSystemStorage
import mimetypes
from django.conf import settings
from django.core.mail import EmailMessage


def raiserequest(request):
    if request.method=="POST":
        username=request.POST["username"]
        password=request.POST["password"]
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            obj=user_profile.objects.get(user=user)
            print(obj.user.id)
            return HttpResponseRedirect(reverse("raiserequest1",args=(obj.user.id,)))
        else:
            messages.info(request,"Invalid Credentials")
            return redirect("raiserequest") 
    else:
        return render(request,"index.html")

def raiserequest1(request,objid):
    user=get_object_or_404(User,id=objid)
    print(user.username)
    obj=user_profile.objects.get(user=user)
    return render(request,"dashboard.html",{"obj":obj})


def addopening_view(request,objid):
    '''requistnid="RQS00"
    count=0'''
   
    if request.method=="POST":
        '''count1=+count
        requs=[requistnid+str(count1) for i in range(count1)]
            
        print(requs)
        count=0
        count+=1
        count=count+1
        print('The Value of Count is',count)
        '''
        rid=request.POST["rid"]
        resby=request.POST["resby"]
        posname=request.POST["posname"]
        client=request.POST["client"]
        proj=request.POST["proj"]
        reqtype=request.POST["reqtype"]
        restype=request.POST["restype"]
        nop=request.POST["nop"]
        apvdbud=request.POST["apvdbud"]
        mhscod=request.POST["mhscod"]
        gthsc=request.POST["gthsc"]
        totexpy=request.POST["totexpy"]
        totexpm=request.POST["totexpm"]
        rey=request.POST["rey"]
        rem=request.POST["rem"]
        highqua=request.POST["highqua"]
        certftn=request.POST["certftn"]
        cerdet=request.POST["cerdet"]
        cabfacility=request.POST["cabfacility"]
        shiftjob=request.POST["shiftjob"]
        jloc=request.POST["jloc"]
        interloc=request.POST["interloc"]
        bond=request.POST["bond"]
        bondmon=request.POST["bondmon"]
        deslevl=request.POST["deslevl"]
        reqexp=request.POST["reqexp"]
        poslevl=request.POST["poslevl"]
        minctc=request.POST["minctc"]   
        maxctc=request.POST["maxctc"]
        hbydate=request.POST["hbydate"]
        uploadresume=request.FILES["uploadresume"]
        fs=FileSystemStorage()
        uploadresume=fs.save(uploadresume.name,uploadresume)
        spcond=request.POST["spcond"]
        technology=request.POST["technology"]
        jobdescrip=request.POST["jobdescrips"]
        user=get_object_or_404(User,id=objid)
        pmname=user.username
        obj=addopening_model.objects.create(pmname=pmname,technology=technology,rid=rid, resby=resby, posname=posname, client=client, proj=proj, reqtype=reqtype, restype=restype, 
                                            nop=nop, apvdbud=apvdbud, mhscod=mhscod,gthsc=gthsc,totexpm_m=totexpy,totexpy_m=totexpm,
                                            rey_m=rey,rem_m=rem,highqua=highqua,certftn=certftn,cerdet=cerdet,cabfacility=cabfacility,shiftjob=shiftjob,
                                            jloc=jloc,interloc=interloc,bond=bond,bondmon=bondmon,deslevl=deslevl,reqexp=reqexp,poslevel=poslevl,
                                            minctc=minctc,maxctc=maxctc,hbydate=hbydate,uploadresume=uploadresume,splcond=spcond,jobdescrips=jobdescrip,receivedate=datetime.now())
        obj.save()
        posid_ch=[rid+"posid"+str(i) for i in range(int(nop))]
        for i in posid_ch:
            obj1=POID_assign_model.objects.create(posrid=obj, posid=i)
            obj1.save()
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    proj_ch=addopening_model.proj_ch
    jloc_ch=addopening_model.jloc_ch
    rey=addopening_model.rey
    rem=addopening_model.rem
    totexpy=addopening_model.totexpy
    totexpm=addopening_model.totexpm
    restype_ch=addopening_model.restype_ch
    resby_ch=addopening_model.resby_ch
    certftn_ch=addopening_model.certftn_ch
    cabfacility_ch=addopening_model.cabfacility_ch
    deslevl_ch=addopening_model.deslevl_ch
    client_ch=addopening_model.client_ch
    reqtype_ch=addopening_model.reqtype_ch
    bond_ch=addopening_model.bond_ch
    return render(request,"add_openingpm.html",{"deslevl_ch":deslevl_ch,"reqtype_ch":reqtype_ch,"bond_ch":bond_ch,"cabfacility_ch":cabfacility_ch,"certftn_ch":certftn_ch,"obj":obj,"jloc_ch":jloc_ch,"client_ch":client_ch,"rey":rey,"rem":rem,"proj_ch":proj_ch,"totexpy":totexpy,"totexpm":totexpm,"restype_ch":restype_ch,"resby_ch":resby_ch,"client_ch":client_ch,"deslevl_ch":deslevl_ch,"reqtype_ch":reqtype_ch})

def viewopening_view(request,objid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    #obj=request.session['obj']
    addopendata=addopening_model.objects.all()
    if obj.dsg == "Recuiter":
        posid_cond=POID_assign_model.objects.filter(assignto=user.username)
        return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata,"posid_cond":posid_cond}) 
    else:
        return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata}) 
    
def addcandidate_view(request,objid,posridp):
    if request.method=="POST":
        assignedposid=POID_assign_model.objects.get(posid=posridp)
        fname=request.POST["fname"]
        mname=request.POST["mname"]
        lname=request.POST["lname"]
        contactno=request.POST["contactno"]
        emailid=request.POST["emailid"]
        dob=request.POST["dob"]
        tchnolgy=request.POST["tchnolgy"]
        ssiany=request.POST["ssiany"]
        certiany=request.POST["certiany"]
        highedu=request.POST["highedu"]
        totexpy_m=request.POST["totexpy_m"]
        totexpm_m=request.POST["totexpm_m"]
        relevtm_m=request.POST["relevtm"]
        relevty_m=request.POST["relevty"]
        currctct_T=request.POST["currctct_T"]
        currctcl_L=request.POST["currctct_L"]
        expectct_T=request.POST["expectct_T"]
        expctcl_L=request.POST["expectct_L"]
        gender=request.POST["gender"]
        currorganztn=request.POST["currorganztn"]
        notcperd=request.POST["notcperd"]
        srce=request.POST["srce"]
        prfdloc=request.POST["prfdloc"]
        currloc=request.POST["currloc"]
        pancrd=request.POST["pancrd"]
        passport=request.POST["passport"]
        reaorchange=request.POST["reaorchange"]
        status=addcandidate_model.status_ch[4][0]
        uploadresumecan=request.FILES["uploadresumecan"]
        fs=FileSystemStorage()
        uploadresumecan=fs.save(uploadresumecan.name,uploadresumecan)
        obj=addcandidate_model.objects.create(assignedposid=assignedposid,gender=gender,uploadresumecan=uploadresumecan,received_date=datetime.now(),status=status,fname=fname,mname=mname,lname=lname,contactno=contactno,emailid=emailid,dob=dob,
                                              tchnolgy=tchnolgy,ssiany=ssiany,certiany=certiany,highedu=highedu,currorganztn=currorganztn,
                                              notcperd=notcperd,srce=srce,prfdloc=prfdloc,currloc=currloc,pancrd=pancrd,passport=passport,
                                              reaorchange=reaorchange,totexpm_m=totexpm_m,totexpy_m=totexpy_m,
                                              relevty_m=relevty_m,relevtm_m=relevtm_m,currctct_T=currctct_T,currctcl_L=currctcl_L,expectct_T=expectct_T,expctcl_L=expctcl_L)
        obj.save()
        return render(request,"candidate_details.html",{"obj":obj,"emailid":emailid})    
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    totexpm=addcandidate_model.totexpm
    totexpy=addcandidate_model.totexpy
    relevtm=addcandidate_model.relevtm
    relevty=addcandidate_model.relevty
    currctct=addcandidate_model.currctct
    currctcl=addcandidate_model.currctcl
    expectct=addcandidate_model.expectct
    expctcl=addcandidate_model.expctcl
    gender_ch=addcandidate_model.gender_ch
    #obj=request.session['obj']
    assignedposid=POID_assign_model.objects.get(posid=posridp)
    addcandidate=addopening_model.objects.get(rid=assignedposid.posrid.rid)
    return render(request,"add_candidate.html",{"obj":obj,"addcandidate":addcandidate,"assignedposid":assignedposid,"totexpm":totexpm,"totexpy":totexpy,"relevtm":relevtm,"relevty":relevty,"currctct":currctct,
                                                "currctcl":currctcl,"expectct":expectct,"expctcl":expctcl,"gender_ch":gender_ch})
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    addcand=addopening_model.objects.get(rid=posridp)
    '''assignedrtl=addcandidate_model.objects.'''
    return render(request,"add_candidate.html",{"obj":obj,"addcand":addcand})

def assign_recuiter_view(request,objid,rid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    addopendata=addopening_model.objects.get(rid=rid)
    posid_field=POID_assign_model.objects.filter(posrid=addopendata)
    recuiters_name=user_profile.objects.filter(dsg="Recuiter")
    if request.method=="POST":
        print("hello")
        for i in posid_field:
            
            i.assignto=request.POST["assign_"+i.posid]
            i.posidassignedbyrtl=obj.user.username
            i.save()
            newcmd=commentlist_model.objects.create(pmname=user.username,dsg=obj.dsg,modifieddate=datetime.now(),comment=i.posid+request.POST["comment_"+i.posid])
            newcmd.save()
            print(request.POST["assign_"+i.posid])
        addopendata=addopening_model.objects.all()
        return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata})
    if posid_field[0].assignto=="":
        return render(request,"assign_recruiter.html",{"obj":obj,"recuiters_name":recuiters_name,"addopendata":addopendata,"posid_field":posid_field})
    else:
        addopendata=addopening_model.objects.all()
        return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata})

def detail_openingpm_view(request,objid,rid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    if obj.dsg == "Recuiter":
        posid_obj=POID_assign_model.objects.get(posid=rid)
        addopendata=posid_obj.posrid
    else:
        addopendata=addopening_model.objects.get(rid=rid)
    if request.method=="POST":
        if  obj.dsg=="pm":
            comment=request.POST["comment"]
            newcmd=commentlist_model.objects.create(pmname=user.username,dsg=obj.dsg,modifieddate=datetime.now(),comment=comment)
            newcmd.save()
        elif obj.dsg =="RTL":
            comment=request.POST["comment"]
            status=request.POST["status"]
            history=history_model.objects.create(PreviousValue=addopendata.status,modifieddate=datetime.now(),CurrentValue=status,modifiedby=user.username,ridhistory=addopendata)
            history.save()
            newcmd=commentlist_model.objects.create(status=status,pmname=user.username,dsg=obj.dsg,modifieddate=datetime.now(),comment=comment)
            newcmd.save()
            addopendata.status=status
            addopendata.save()
            
        else:
            reqstatus=request.POST["status"]
            posid_obj.reqstatus=reqstatus
            posid_obj.save()
    cmddetails=commentlist_model.objects.all()
    if obj.dsg == "Recuiter":
        return render(request,"detail_openingpm.html",{"obj":obj,"posid_obj":posid_obj,"addopendata":addopendata,"cmddetails":cmddetails})
    historydetail=history_model.objects.filter(ridhistory=addopendata)
    return render(request,"detail_openingpm.html",{"obj":obj,"addopendata":addopendata,"cmddetails":cmddetails,"historydetail":historydetail})

def edit_opening_pm_view(request,objid,rid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    addopendata=addopening_model.objects.all(rid=rid)
    if request.method=="POST":
        if addopendata.rid=="rid":
            
            resby=request.POST["resby"]
            posname=request.POST["posname"]
            client=request.POST["client"]
            proj=request.POST["proj"]
            reqtype=request.POST["reqtype"]
            restype=request.POST["restype"]
            nop=request.POST["nop"]
            apvdbud=request.POST["apvdbud"]
            mhscod=request.POST["mhscod"]
            gthsc=request.POST["gthsc"]
            totexpy=request.POST["totexpy"]
            totexpm=request.POST["totexpm"]
            rey=request.POST["rey"]
            rem=request.POST["rem"]
            highqua=request.POST["highqua"]
            certftn=request.POST["certftn"]
            cerdet=request.POST["cerdet"]
            cabfacility=request.POST["cabfacility"]
            shiftjob=request.POST["shiftjob"]
            jloc=request.POST["jloc"]
            interloc=request.POST["interloc"]
            bond=request.POST["bond"]
            bondmon=request.POST["bondmon"]
            deslevl=request.POST["deslevl"]
            reqexp=request.POST["reqexp"]
            poslevl=request.POST["poslevl"]
            minctc=request.POST["minctc"]   
            maxctc=request.POST["maxctc"]
            hbydate=request.POST["hbydate"]
            uploadresume=request.FILES["uploadresume"]
            fs=FileSystemStorage()
            uploadresume=fs.save(uploadresume.name,uploadresume)
            spcond=request.POST["spcond"]
            technology=request.POST["technology"]
            jobdescrip=request.POST["jobdescrips"]
            user=get_object_or_404(User,id=objid)
            pmname=user.username
            
            editopngdetails=addopening_model.objects.update(pmname=pmname,technology=technology,rid=rid, resby=resby, posname=posname, client=client, proj=proj, reqtype=reqtype, restype=restype, 
                                            nop=nop, apvdbud=apvdbud, mhscod=mhscod,gthsc=gthsc,totexpm_m=totexpy,totexpy_m=totexpm,
                                            rey_m=rey,rem_m=rem,highqua=highqua,certftn=certftn,cerdet=cerdet,cabfacility=cabfacility,shiftjob=shiftjob,
                                            jloc=jloc,interloc=interloc,bond=bond,bondmon=bondmon,deslevl=deslevl,reqexp=reqexp,poslevel=poslevl,
                                            minctc=minctc,maxctc=maxctc,hbydate=hbydate,uploadresume=uploadresume,splcond=spcond,jobdescrips=jobdescrip,receivedate=datetime.now())
            editopngdetails.save()
            return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata}) 
        else:
           return render(request,"view_openingpm.html",{"obj":obj,"addopendata":addopendata}) 


def view_candidate(request,objid,rid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    if obj.dsg=="pm":
        pass
    else:
        posid_cond=POID_assign_model.objects.get(posid=rid)
        cand_details=addcandidate_model.objects.filter(assignedposid=posid_cond)
        if request.method=="POST":
            candicheck=request.POST.getlist("checks[]")
            canddetails=",".join(candicheck)
            print(canddetails)
            return redirect("send_candidate_view",objid=objid,posid=rid,canddetails=canddetails)
    return render(request,"view_candidate.html",{"obj":obj,"posid_cond":posid_cond,"cand_details":cand_details})

def candidate_details_view(request,objid,emailid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    print(emailid)
    cand_details=addcandidate_model.objects.get(emailid=emailid)
    
    return render(request,'candidate_details.html',{"obj":obj,"cand_details":cand_details})

def dowloadfile(request,candidatedetails):
    f1_path=str(settings.BASE_DIR)+"\\media"
    filename=str(candidatedetails)
    f1=open(f1_path,"r")
    mime_type, _ = mimetypes.guess_type(f1_path)
    response = HttpResponse(f1, content_type=mime_type)
    response['Content-Disposition'] = "attachment; filename=%s" % filename
    return response
    

def selectedcandidate_view(request,objid,emailid,rid,candrid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    posid_cond=POID_assign_model.objects.get(posid=rid)
    cand_details=addcandidate_model.objects.filter(assignedposid=posid_cond)
    addopendata=addopening_model.objects.get(rid=candrid)
    return render(request,'candidate_details.html',{"obj":obj,"posid_cond":posid_cond,"addopendata":addopendata})

def deletecandidate_view(request,objid,rid,emailid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    posid_cond=POID_assign_model.objects.get(posid=rid)
    candidate_detail=addcandidate_model.objects.filter(assignedposid=posid_cond,emailid=emailid).delete()
    return redirect("view_candidate",objid=objid,rid=rid)

def viewcandidatepm_view(request,objid):
    details={}
    viewopening=addopening_model.objects.filter(status="Accepted")
    for i in viewopening:
        posid_variable=POID_assign_model.objects.filter(posrid=i)
        for j in posid_variable:
            candidatedetails=addcandidate_model.objects.filter(status__in=["Onhold","Interview_Schedule"],assignedposid=j)
            details[j]=candidatedetails
    return render(request,"view_candidate_pm.html",{"details":zip(details.keys(),details.values())})        
 
def viewcandidatertl_view(request,objid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    details={}
    qual=[""]
    tchnolgy=[""]
    viewopening=addopening_model.objects.filter(status="Accepted")
    for i in viewopening:
        posid_variable=POID_assign_model.objects.filter(posrid=i)
        for j in posid_variable:
            candidatedetails=addcandidate_model.objects.filter(status__in=["Onhold","Interview_Schedule"],assignedposid=j)
            for k in candidatedetails:
                qual.append(k.highedu)
                tchnolgy.append(k.tchnolgy)
            if request.method == "POST":
                newstatus=addcandidate_model.objects.filter(status="Onhold",assignedposid=j)
                qual_v=request.POST.get("for_qua")
                if len(qual_v)==0:
                    qual_v=[]
                    for i in newstatus:
                        qual_v.append(i.highedu)
                else:
                    qual_v=[qual_v]
                tchnolgy_v=request.POST.get("for_industry")
                if len(tchnolgy_v)==0:
                    tchnolgy_v=[i.tchnolgy for i in newstatus]
                else:
                    tchnolgy_v=[tchnolgy_v]
                name_v=request.POST.get("s_name")
                if len(name_v) ==0:
                    name_v=[i.fname for i in newstatus]
                else:
                    name_v=[name_v]
                from_v=request.POST.get("keyword1")
                to_v=request.POST.get("keyword2")
                if len(to_v)==0:
                    expt_v=[i.totexpy_m for i in newstatus]
                else:
                    expt_v=[i for i in range(int(from_v),int(to_v)+1)]
                candidatedetails=addcandidate_model.objects.filter(status__in=["Onhold","Interview_Schedule"],assignedposid=j,highedu__in=qual_v,tchnolgy__in=tchnolgy_v,fname__in=name_v,totexpm_m__in=expt_v)    
            details[j]=candidatedetails
    return render(request,"view_candidate_rtl.html",{"details":zip(details.keys(),details.values()),"count":1,"qual":qual,"tchnolgy":tchnolgy})        
           
def candidate_details_pm_view(request,objid,emailid):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    sortcandidate=addcandidate_model.objects.get(emailid=emailid)
    if request.method == "POST":
        status=request.POST["opening_industry"]
        sortcandidate.status=status
        sortcandidate.save()
        comment=request.POST["comment"]
        newcmd=commentlist_model.objects.create(pmname=user.username,dsg=obj.dsg,cmddetails=datetime.now(),comment=comment)
        newcmd.save()
        return redirect("viewcandidatepm_view",objid=objid)
    return redirect(request,"candidate_details__pm.html",{"obj":obj,"sortcandidate":sortcandidate})

def send_candidate_view(request,objid,posid,canddetails):
    user=get_object_or_404(User,id=objid)
    obj=user_profile.objects.get(user=user)
    assignedposid=POID_assign_model.objects.get(posid=posid)
    addcandidate=addopening_model.objects.get(rid=assignedposid.posrid.rid)
    canddetails=canddetails.split(",")
    cand_list=[]
    f_l,f=[],[]
    emailbody="Dear Sir,\n Candidate list for {} under {}".format(assignedposid.posrid.rid,assignedposid.posid)
    title="Candidate List for {} under {}".format(assignedposid.posrid.rid,assignedposid.posid)
    for i in canddetails:
        l=addcandidate_model.objects.get(emailid=i)
        cand_list.append(l)
        emailbody+="{} : {} \n".format(l.fname,l.emailid)
        f.append(str(l.uploadresumecan))
        f_l.append(str(settings.BASE_DIR)+"\\media\\"+str(l.uploadresumecan))
    to="rash9784@gmail.com"
    tomail=User.objects.get(username=addcandidate.pmname)
    print(tomail.email)
    cc="rash9784@gmail.com"
    #ccmail=
    #print(assignedposid.assignedby.email)
    if request.method=="POST":
        to=to.split(",")
        cc=cc.split(",")
        email = EmailMessage(
            title,
            emailbody,
            settings.EMAIL_HOST_USER,
            to,
            cc,
            headers={'Message-ID': 'foo'})
        for i in f_l:
            email.attach_file(i)
        email.send(fail_silently=False)
        for i in canddetails:
            l=addcandidate_model.objects.get(emailid=i)
            l.status=l.status_ch[3][0]
            l.save()
        return redirect("view_candidate",objid=objid,rid=posid)
    return render(request,"send_candidate.html",{"obj":obj,"to":to,"cc":cc,"title":title,"emailbody":emailbody,"f":str(f)})
            


def signout(request):
    auth.logout(request)
    return redirect("raiserequest")