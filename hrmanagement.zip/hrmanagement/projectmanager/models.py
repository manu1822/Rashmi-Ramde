from django.db import models
from django.contrib.auth.models import User
class user_profile(models.Model):
    #joining date,designation,doj,profile
    user=models.OneToOneField(User, on_delete=models.CASCADE,null=True)#cascade is use if something get deleted it will get delete from another table 
    #onetoone is one connection with table
    doj=models.DateField(default="2000-01-01")
    dsg_ch=(("pm","ProjectManager"),("RTL","RecuiterTL"),("Recuiter","Recuiter"))
    dsg=models.CharField(max_length=30,choices=dsg_ch,default='RTL')
    profile=models.ImageField(upload_to="pics",default='pics/thumb1.png')
    

    
class addopening_model(models.Model):
    pmname=models.CharField(max_length=50,default="")
    rid=models.CharField(max_length=50,default="")
    resby_ch=(("Select","Select"),("PojectManager","ProjectManager"),("Advisor","Advisor"),("Tl","Tl"),("select","select"))
    resby=models.CharField(max_length=30,choices=resby_ch,default='select')
    posname=models.CharField(max_length=50,default="")
    client_ch=(("Select","Select"),("PTC","PTC"),("TCS","TCS"),("Infosys","Infosys"),("select","select"))
    client=models.CharField(max_length=30,choices=client_ch,default='select')
    proj_ch=(("Select","Select"),("tlc","tlc"),("phton","phton"),("texta","texta"),("select","select"))
    proj=models.CharField(max_length=30,choices=proj_ch,default='select')
    reqtype=models.CharField(max_length=50,default="")
    restype_ch=(("Select","Select"),("Contract","Contract"),("Fulltime","Fulltime"),("Parttime","Parttime"),("select","select"))
    restype=models.CharField(max_length=30,choices=restype_ch,default='select')
    nop=models.CharField(max_length=50,default="")
    apvdbud=models.CharField(max_length=50,default="")
    mhscod=models.CharField(max_length=50,default="")
    gthsc=models.CharField(max_length=50,default="")
    totexpm=[(str(i),str(i)) for i in range(0,21)]
    totexpy=[(str(i),str(i)) for i in range(0,21)]
    totexpm_m=models.CharField(max_length=30,choices=totexpm,default='0')
    totexpy_m=models.CharField(max_length=30,choices=totexpy,default='0')
    rem=[(str(i),str(i)) for i in range(0,21)]
    rey=[(str(i),str(i)) for i in range(0,13)]
    rey_m=models.CharField(max_length=30,choices=rey,default='0')
    rem_m=models.CharField(max_length=30,choices=rem,default='0')
    highqua=models.CharField(max_length=50,default="")
    certftn_ch=(("Yes","Yes"),("No","No"))
    certftn=models.CharField(max_length=30,choices=certftn_ch,default='No')
    cerdet=models.CharField(max_length=50,default="")
    cabfacility_ch=(("Yes","Yes"),("No","No"))
    cabfacility=models.CharField(max_length=30,choices=cabfacility_ch,default='No')
    shiftjob=models.CharField(max_length=50,default="")
    jloc_ch=(("Select","Select"),("Noida","Noida"),("Pune","Pune"),("Coimbatore","Coimbatore"))
    jloc=models.CharField(max_length=30,choices=jloc_ch,default="")
    interloc=models.CharField(max_length=50,default="")
    reqtype_ch=(("Select","Select"),("Experienced","Expericenced"),("Fresher","Fresher"))
    reqtype=models.CharField(max_length=30,choices=reqtype_ch,default="")
    bond_ch=(("Yes","Yes"),("No","No"))
    bond=models.CharField(max_length=50,default="")
    bondmon=models.CharField(max_length=50,default="")
    deslevl_ch=(("Select","Select"),("Advisor","Advisor"),("Developer","Developer"),("Tester","Tester"))
    deslevl=models.CharField(max_length=30,choices=deslevl_ch,default="")
    reqexp=models.CharField(max_length=50,default="")
    poslevel=models.CharField(max_length=50,default="")
    minctc=models.CharField(max_length=50,default="")
    maxctc=models.CharField(max_length=50,default="")
    hbydate=models.CharField(max_length=50,default="")
    uploadresume=models.FileField(upload_to="uploadresume",default='resumee/Scope.docx')
    splcond=models.CharField(max_length=50,default="")
    technology=models.CharField(max_length=30,default="")
    jobdescrips=models.CharField(max_length=50,default="")
    status_ch=(("Select","Select"),("Accepted","Accepted"),("Rejected","Rejected"),("Onhold","Onhold"),("Need Clarification","Need Clarification"),("Select","Select"))
    status=models.CharField(max_length=30,choices=status_ch,default="")
    receivedate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    assigneddate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    action_ch=("Inprocess","Inprocess"),("Stopped","Stopped")
    status=models.CharField(max_length=30,choices=status_ch,default="")
    
class commentlist_model(models.Model):
    pmname=models.CharField(max_length=30,default="")
    dsg=models.CharField(max_length=30,default="")
    modifieddate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    comment=models.CharField(max_length=100,default="")

class POID_assign_model(models.Model):
    posrid=models.ForeignKey(addopening_model, on_delete=models.CASCADE,null=True)
    posid=models.CharField(max_length=30,default="")
    assignto=models.CharField(max_length=30,default="")
    status_ch=(("Accepted","Accepted"),("Rejected","Rejected"),("NeedValidation","Needvalidation"))
    reqstatus=models.CharField(max_length=30,choices=status_ch,default="NeedValidation")
    posidassignedbyrtl=models.CharField(max_length=30,default="")
    
class addcandidate_model(models.Model):
    assignedposid=models.ForeignKey(POID_assign_model, on_delete=models.CASCADE,null=True)
    #generaterid= models.IntegerField()
    status_ch=(("Select","Select"),("Accepted","Accepted"),("Rejected","Rejected"),("Onhold","Onhold"),("Need Clarification","Need Clarification"),("Select","Select"))
    status=models.CharField(max_length=30,choices=status_ch,default="")
    assigned_date=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    received_date=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    uploadresumecan=models.FileField(upload_to="uploadresumecan",default='resumee/Scope.docx')
    fname=models.CharField(max_length=50,default="")
    mname=models.CharField(max_length=50,default="")
    lname=models.CharField(max_length=50,default="")
    contactno=models.CharField(max_length=50,default="")
    emailid=models.CharField(max_length=50,default="")
    dob=models.CharField(max_length=50,default="")
    tchnolgy=models.CharField(max_length=50,default="")
    ssiany=models.CharField(max_length=50,default="")
    certiany=models.CharField(max_length=50,default="")
    highedu=models.CharField(max_length=50,default="")
    totexpm=[(str(i),str(i)) for i in range(0,21)]
    totexpy=[(str(i),str(i)) for i in range(0,21)]
    totexpm_m=models.CharField(max_length=30,choices=totexpm,default='0')
    totexpy_m=models.CharField(max_length=30,choices=totexpy,default='0')
    relevtm=[(str(i),str(i)) for i in range(0,21)]
    relevtm_m=models.CharField(max_length=30,choices=relevtm,default='0')
    relevty=[(str(i),str(i)) for i in range(0,13)]
    relevty_m=models.CharField(max_length=30,choices=relevty,default='0')
    currctct=[(str(i),str(i)) for i in range(0,100)]
    currctct_T=models.CharField(max_length=30,choices=currctct,default='0')
    currctcl=[(str(i),str(i)) for i in range(0,100)]
    currctcl_L=models.CharField(max_length=30,choices=currctcl,default='0')
    expectct=[(str(i),str(i)) for i in range(0,100)]
    expectct_T=models.CharField(max_length=30,choices=expectct,default='0')
    expctcl=[(str(i),str(i)) for i in range(0,100)]
    expctcl_L=models.CharField(max_length=30,choices=expctcl,default='0')
    currorganztn=models.CharField(max_length=50,default="")
    notcperd=models.CharField(max_length=50,default="")
    gender_ch=(("Male","Male"),("Female","Female"))
    gender=models.CharField(max_length=50,default="")
    srce=models.CharField(max_length=50,default="")
    prfdloc=models.CharField(max_length=50,default="")
    currloc=models.CharField(max_length=50,default="")
    pancrd=models.CharField(max_length=50,default="")
    passport=models.CharField(max_length=50,default="")
    reaorchange=models.CharField(max_length=500,default="")  
    assignedby_ch=models.ForeignKey(addopening_model, on_delete=models.CASCADE,null=True)
    assignedby=models.CharField(max_length=50,default="")
    selectedcandstatus=models.BooleanField(default=False)
    
'''class pmrtldetailscand_model(models.Model):
    pmgoaheddate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    initialdocdate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    hrscheduleddate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    hrscheduledtime=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    hrpersonname=models.CharField(max_length=50,default="")
    hrdiscussiondate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    resignaccpmailshardate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    prejoingscheduledate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    currentlocationofcand=models.ForeignKey(addcandidate_model, on_delete=models.CASCADE,null=True)
    owncompanyloc=models.CharField(max_length=50,default="")
    employeerefcost=models.CharField(max_length=50,default="")
    joiningcmment=models.CharField(max_length=500,default="")
    apprvdforposition=models.ForeignKey(addopening_model, on_delete=models.CASCADE,null=True)
    recuitername=models.CharField(max_length=50,default="")
    projectmngrname=models.CharField(max_length=50,default="")
    clientname=models.ForeignKey(addopening_model, on_delete=models.CASCADE,null=True)
    candidateid=models.CharField(max_length=50,default="")
    candidatereviewstatus_ch=(("Select","Select"),("Accepted","Accepted"),("Rejected","Rejected"),("Onhold","Onhold"),("Need Clarification","Need Clarification"),("Select","Select"))
    candidatereviewstatus=models.CharField(max_length=30,choices=candidatereviewstatus_ch,default="")
    '''
class history_model(models.Model):
    
    PreviousValue=models.CharField(max_length=500,default="")
    modifieddate=models.DateTimeField(default="2021-05-17 22:10:04.992741",null=True, blank=True)
    propertychange=models.CharField(max_length=500,default="")
    CurrentValue=models.CharField(max_length=500,default="")
    modifiedby=models.CharField(max_length=30,default="")
    ridhistory=models.ForeignKey(addopening_model, on_delete=models.CASCADE,null=True)
    candidatehistory=models.ForeignKey(addcandidate_model, on_delete=models.CASCADE,null=True)

    
    

    
    
    
    
    
    
    
    
    
   
    
    