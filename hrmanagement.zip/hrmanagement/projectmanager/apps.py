from django.apps import AppConfig


class ProjectmanagerConfig(AppConfig):
    name = 'projectmanager'
