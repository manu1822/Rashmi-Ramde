from django.contrib import admin
from .models import user_profile,addopening_model,POID_assign_model
class user_admin(admin.ModelAdmin):
    list_display=['dsg','doj','user']
    list_editable=['doj']
admin.site.register(user_profile,user_admin)
admin.site.register(addopening_model)
admin.site.register(POID_assign_model)

