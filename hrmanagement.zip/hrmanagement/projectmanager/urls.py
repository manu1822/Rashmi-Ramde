from django.urls import path
from.import views
urlpatterns = [
   path('',views.raiserequest,name="raiserequest"),
   path('dashboard/<int:objid>/',views.raiserequest1,name="raiserequest1"),
   path('dashboard/<int:objid>/add_opening/',views.addopening_view,name="addopening_view"),
   path('dashboard/<int:objid>/view_opening/',views.viewopening_view,name="viewopening_view"),
   path('dashboard/<int:objid>/<str:rid>/detail_View',views.detail_openingpm_view,name="detail_openingpm_view"),
   path('dashboard/<int:objid>/<str:posridp>/add_candidate',views.addcandidate_view,name="addcandidate_view"),
   path('dashboard/<int:objid>/<str:rid>/assign_recuiter',views.assign_recuiter_view,name="assign_recuiter_view"),
   path('dashboard/<int:objid>/<str:rid>/view_candidate',views.view_candidate,name="view_candidate"),
   path('dashboard/<int:objid>/<str:emailid>/candidate_details/',views.candidate_details_view,name="candidate_details_view"),
   path('dashboard/<int:objid>/<str:posid>/<str:canddetails>/SendCandidate/',views.send_candidate_view,name="send_candidate_view"),
   path('dashboard/<int:objid>/<str:rid>/<str:emailid>/DeleteCandidate/',views.deletecandidate_view,name="deletecandidate_view"),
   path('dashboard/<int:objid>/viewcandidatepm/',views.viewcandidatepm_view,name="viewcandidatepm_view"),
   path('dashboard/<int:objid>/viewcandidatertl/',views.viewcandidatertl_view,name="viewcandidatertl_view"),
   path('dashboard/<str:candidatedetails>/dowloadfile/',views.dowloadfile,name="dowloadfile"),
   path('signout/',views.signout,name="signout")
]
